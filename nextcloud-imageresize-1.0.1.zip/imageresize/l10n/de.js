OC.L10N.register('imageresize', {
    "Image Resize": "Bildgrößenanpassung",
    "Automatically resize newly uploaded photos in the background using ImageMagick.": "Neu hochgeladene Fotos automatisch im Hintergrund mit ImageMagick verkleinern.",
    "Enable automatic resizing": "Automatische Größenanpassung aktivieren",
    "Maximum width (px)": "Maximale Breite (px)",
    "Maximum height (px)": "Maximale Höhe (px)",
    "JPEG/WebP quality": "JPEG-/WebP-Qualität",
    "Maximum source size (MB)": "Maximale Größe der Quelldatei (MB)",
    "Remove EXIF and other metadata": "EXIF- und andere Metadaten entfernen",
    "Skip animated and multi-frame images": "Animierte Bilder und Bilder mit mehreren Frames überspringen",
    "Excluded folders": "Ausgeschlossene Ordner",
    "One folder path per line. Matching is performed within each user’s files.": "Ein Ordnerpfad pro Zeile. Die Prüfung erfolgt innerhalb der Dateien des jeweiligen Benutzers.",
    "Save": "Speichern",
    "Saving…": "Wird gespeichert…",
    "Saved": "Gespeichert",
    "Could not save the settings": "Die Einstellungen konnten nicht gespeichert werden",
    "PHP Imagick is not available. Install and enable php-imagick before activating processing.": "PHP Imagick ist nicht verfügbar. Installieren und aktivieren Sie php-imagick, bevor Sie die Verarbeitung einschalten."
}, 'nplurals=2; plural=(n != 1);');
