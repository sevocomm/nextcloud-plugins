OC.L10N.register('imageresize', {
    "Image Resize": "Image Resize",
    "Automatically resize newly uploaded photos in the background using ImageMagick.": "Automatically resize newly uploaded photos in the background using ImageMagick.",
    "Enable automatic resizing": "Enable automatic resizing",
    "Maximum width (px)": "Maximum width (px)",
    "Maximum height (px)": "Maximum height (px)",
    "JPEG/WebP quality": "JPEG/WebP quality",
    "Maximum source size (MB)": "Maximum source size (MB)",
    "Remove EXIF and other metadata": "Remove EXIF and other metadata",
    "Skip animated and multi-frame images": "Skip animated and multi-frame images",
    "Excluded folders": "Excluded folders",
    "One folder path per line. Matching is performed within each user’s files.": "One folder path per line. Matching is performed within each user’s files.",
    "Save": "Save",
    "Saving…": "Saving…",
    "Saved": "Saved",
    "Could not save the settings": "Could not save the settings",
    "PHP Imagick is not available. Install and enable php-imagick before activating processing.": "PHP Imagick is not available. Install and enable php-imagick before activating processing."
}, 'nplurals=2; plural=(n != 1);');
