OC.L10N.register('imageresize', {
    'Image Resize': 'Afbeeldingen verkleinen',
    'Automatically resize newly uploaded photos in the background using ImageMagick.': 'Verklein nieuw geüploade foto’s automatisch op de achtergrond met ImageMagick.',
    'Enable automatic resizing': 'Automatisch verkleinen inschakelen',
    'Maximum width (px)': 'Maximale breedte (px)',
    'Maximum height (px)': 'Maximale hoogte (px)',
    'JPEG/WebP quality': 'JPEG/WebP-kwaliteit',
    'Maximum source size (MB)': 'Maximale bronbestandsgrootte (MB)',
    'Remove EXIF and other metadata': 'EXIF en andere metadata verwijderen',
    'Skip animated and multi-frame images': 'Geanimeerde afbeeldingen en afbeeldingen met meerdere frames overslaan',
    'Excluded folders': 'Uitgesloten mappen',
    'One folder path per line. Matching is performed within each user’s files.': 'Eén mappad per regel. De controle gebeurt binnen de bestanden van iedere gebruiker.',
    'Save': 'Opslaan',
    'Saving…': 'Opslaan…',
    'Saved': 'Opgeslagen',
    'Could not save the settings': 'De instellingen konden niet worden opgeslagen',
    'PHP Imagick is not available. Install and enable php-imagick before activating processing.': 'PHP Imagick is niet beschikbaar. Installeer en activeer php-imagick voordat verwerking wordt ingeschakeld.'
}, 'nplurals=2; plural=(n != 1);');
