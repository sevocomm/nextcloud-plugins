(function () {
    'use strict';
    document.addEventListener('DOMContentLoaded', function () {
        const root = document.getElementById('imageresize-settings');
        if (!root) return;
        const button = document.getElementById('ir-save');
        const status = document.getElementById('ir-status');
        button.addEventListener('click', async function () {
            button.disabled = true;
            status.textContent = t('imageresize', 'Saving…');
            const body = new URLSearchParams({
                enabled: document.getElementById('ir-enabled').checked ? 'true' : 'false',
                maxWidth: document.getElementById('ir-max-width').value,
                maxHeight: document.getElementById('ir-max-height').value,
                quality: document.getElementById('ir-quality').value,
                maxInputMb: document.getElementById('ir-max-input').value,
                stripMetadata: document.getElementById('ir-strip').checked ? 'true' : 'false',
                skipAnimated: document.getElementById('ir-skip-animated').checked ? 'true' : 'false',
                excludedFolders: document.getElementById('ir-excluded').value,
                requesttoken: OC.requestToken
            });
            try {
                const response = await fetch(root.dataset.saveUrl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
                    body: body.toString()
                });
                if (!response.ok) throw new Error('HTTP ' + response.status);
                status.textContent = t('imageresize', 'Saved');
            } catch (e) {
                status.textContent = t('imageresize', 'Could not save the settings');
                console.error(e);
            } finally {
                button.disabled = false;
            }
        });
    });
})();
