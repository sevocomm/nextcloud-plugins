<?php

declare(strict_types=1);

namespace OCA\ImageResize\BackgroundJob;

use OCA\ImageResize\AppInfo\Application;
use OCA\ImageResize\Service\ImageResizer;
use OCP\BackgroundJob\QueuedJob;
use OCP\Files\IRootFolder;
use OCP\IConfig;
use Psr\Log\LoggerInterface;

final class ResizeImageJob extends QueuedJob {
    public function __construct(
        private IRootFolder $rootFolder,
        private IConfig $config,
        private ImageResizer $resizer,
        private LoggerInterface $logger,
    ) {
    }

    protected function run($argument): void {
        if (!is_array($argument) || !isset($argument['ownerUid'], $argument['fileId'])) {
            return;
        }

        if ($this->config->getAppValue(Application::APP_ID, 'enabled', '1') !== '1') {
            return;
        }

        try {
            $userFolder = $this->rootFolder->getUserFolder((string)$argument['ownerUid']);
            $nodes = $userFolder->getById((int)$argument['fileId']);
            if ($nodes === []) {
                return;
            }

            $file = $nodes[0];
            if (isset($argument['mtime']) && $file->getMTime() !== (int)$argument['mtime']) {
                // A newer write will have queued a newer job; do not process stale content.
                return;
            }

            $this->resizer->resize($file);
        } catch (\Throwable $e) {
            $this->logger->error('Image resize job failed: {message}', [
                'app' => Application::APP_ID,
                'message' => $e->getMessage(),
                'exception' => $e,
            ]);
        }
    }
}
