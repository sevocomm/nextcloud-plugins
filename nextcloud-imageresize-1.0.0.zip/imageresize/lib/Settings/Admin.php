<?php

declare(strict_types=1);

namespace OCA\ImageResize\Settings;

use OCA\ImageResize\AppInfo\Application;
use OCP\AppFramework\Http\TemplateResponse;
use OCP\IConfig;
use OCP\Settings\ISettings;

final class Admin implements ISettings {
    public function __construct(private IConfig $config) {
    }

    public function getForm(): TemplateResponse {
        return new TemplateResponse(Application::APP_ID, 'admin', [
            'enabled' => $this->config->getAppValue(Application::APP_ID, 'enabled', '1'),
            'maxWidth' => $this->config->getAppValue(Application::APP_ID, 'max_width', '2560'),
            'maxHeight' => $this->config->getAppValue(Application::APP_ID, 'max_height', '2560'),
            'quality' => $this->config->getAppValue(Application::APP_ID, 'quality', '85'),
            'maxInputMb' => $this->config->getAppValue(Application::APP_ID, 'max_input_mb', '100'),
            'stripMetadata' => $this->config->getAppValue(Application::APP_ID, 'strip_metadata', '0'),
            'skipAnimated' => $this->config->getAppValue(Application::APP_ID, 'skip_animated', '1'),
            'excludedFolders' => $this->config->getAppValue(Application::APP_ID, 'excluded_folders', 'Photos/Originals'),
            'imagickAvailable' => extension_loaded('imagick') && class_exists(\Imagick::class),
        ], '');
    }

    public function getSection(): string {
        return 'imageresize';
    }

    public function getPriority(): int {
        return 10;
    }
}
