<?php

declare(strict_types=1);

namespace OCA\ImageResize\Settings;

use OCP\IL10N;
use OCP\IURLGenerator;
use OCP\Settings\IIconSection;

final class AdminSection implements IIconSection {
    public function __construct(private IL10N $l10n, private IURLGenerator $urlGenerator) {
    }

    public function getID(): string {
        return 'imageresize';
    }

    public function getName(): string {
        return $this->l10n->t('Image Resize');
    }

    public function getPriority(): int {
        return 75;
    }

    public function getIcon(): string {
        return $this->urlGenerator->imagePath('imageresize', 'app-dark.svg');
    }
}
