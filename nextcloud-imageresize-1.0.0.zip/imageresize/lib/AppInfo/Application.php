<?php

declare(strict_types=1);

namespace OCA\ImageResize\AppInfo;

use OCA\ImageResize\Listener\ImageWriteListener;
use OCP\AppFramework\App;
use OCP\AppFramework\Bootstrap\IBootContext;
use OCP\AppFramework\Bootstrap\IBootstrap;
use OCP\AppFramework\Bootstrap\IRegistrationContext;
use OCP\Files\Events\Node\NodeCreatedEvent;
use OCP\Files\Events\Node\NodeWrittenEvent;

final class Application extends App implements IBootstrap {
    public const APP_ID = 'imageresize';

    public function __construct(array $urlParams = []) {
        parent::__construct(self::APP_ID, $urlParams);
    }

    public function register(IRegistrationContext $context): void {
        $context->registerEventListener(NodeCreatedEvent::class, ImageWriteListener::class);
        $context->registerEventListener(NodeWrittenEvent::class, ImageWriteListener::class);
    }

    public function boot(IBootContext $context): void {
    }
}
