<?php

declare(strict_types=1);

namespace OCA\ImageResize\Service;

use OCA\ImageResize\AppInfo\Application;
use OCP\Files\File;
use OCP\IConfig;

final class ResizePolicy {
    private const MIME_TYPES = [
        'image/jpeg',
        'image/png',
        'image/webp',
        'image/heic',
        'image/heif',
        'image/tiff',
    ];

    public function __construct(private IConfig $config) {
    }

    public function isCandidate(File $file): bool {
        if (!in_array($file->getMimeType(), self::MIME_TYPES, true)) {
            return false;
        }

        $maxBytes = max(1, (int)$this->config->getAppValue(Application::APP_ID, 'max_input_mb', '100')) * 1024 * 1024;
        if ($file->getSize() <= 0 || $file->getSize() > $maxBytes) {
            return false;
        }

        $path = '/' . ltrim($file->getPath(), '/');
        $excluded = $this->getExcludedFolders();
        foreach ($excluded as $folder) {
            if ($folder !== '' && str_contains($path, '/' . trim($folder, '/') . '/')) {
                return false;
            }
        }

        return true;
    }

    /** @return string[] */
    public function getExcludedFolders(): array {
        $raw = $this->config->getAppValue(Application::APP_ID, 'excluded_folders', 'Photos/Originals');
        return array_values(array_filter(array_map('trim', preg_split('/[\r\n,]+/', $raw) ?: [])));
    }
}
