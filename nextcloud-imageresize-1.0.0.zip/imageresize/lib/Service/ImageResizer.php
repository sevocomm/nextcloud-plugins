<?php

declare(strict_types=1);

namespace OCA\ImageResize\Service;

use OCA\ImageResize\AppInfo\Application;
use OCP\Files\File;
use OCP\IConfig;
use Psr\Log\LoggerInterface;

final class ImageResizer {
    public function __construct(
        private IConfig $config,
        private ResizePolicy $policy,
        private LoggerInterface $logger,
    ) {
    }

    public function resize(File $file): bool {
        if (!$this->policy->isCandidate($file)) {
            return false;
        }

        if (!extension_loaded('imagick') || !class_exists(\Imagick::class)) {
            throw new \RuntimeException('The PHP Imagick extension is not installed or enabled.');
        }

        $maxWidth = $this->boundedInt('max_width', 2560, 320, 20000);
        $maxHeight = $this->boundedInt('max_height', 2560, 320, 20000);
        $quality = $this->boundedInt('quality', 85, 30, 100);
        $stripMetadata = $this->config->getAppValue(Application::APP_ID, 'strip_metadata', '0') === '1';
        $skipAnimated = $this->config->getAppValue(Application::APP_ID, 'skip_animated', '1') === '1';

        $blob = $file->getContent();
        $image = new \Imagick();

        try {
            $image->readImageBlob($blob);
            if ($image->getNumberImages() > 1 && $skipAnimated) {
                return false;
            }

            $image->setIteratorIndex(0);
            $this->autoOrient($image);
            $width = $image->getImageWidth();
            $height = $image->getImageHeight();

            if ($width <= $maxWidth && $height <= $maxHeight) {
                return false;
            }

            $image->thumbnailImage($maxWidth, $maxHeight, true, true);
            $image->setImagePage(0, 0, 0, 0);

            $format = strtolower($image->getImageFormat());
            if (in_array($format, ['jpeg', 'jpg', 'webp', 'heic', 'heif'], true)) {
                $image->setImageCompressionQuality($quality);
            }

            if ($format === 'png') {
                $image->setOption('png:compression-level', '9');
            }

            if ($stripMetadata) {
                $image->stripImage();
            }

            $result = $image->getImagesBlob();
            if ($result === '' || strlen($result) >= strlen($blob)) {
                // Never replace the original with an empty or larger result.
                return false;
            }

            $file->putContent($result);
            $this->logger->info('Resized {path} from {oldWidth}x{oldHeight} to {newWidth}x{newHeight}', [
                'app' => Application::APP_ID,
                'path' => $file->getPath(),
                'oldWidth' => $width,
                'oldHeight' => $height,
                'newWidth' => $image->getImageWidth(),
                'newHeight' => $image->getImageHeight(),
            ]);
            return true;
        } finally {
            $image->clear();
            $image->destroy();
        }
    }

    private function autoOrient(\Imagick $image): void {
        if (!method_exists($image, 'autoOrient')) {
            return;
        }
        $image->autoOrient();
    }

    private function boundedInt(string $key, int $default, int $min, int $max): int {
        $value = (int)$this->config->getAppValue(Application::APP_ID, $key, (string)$default);
        return max($min, min($max, $value));
    }
}
