<?php

declare(strict_types=1);

namespace OCA\ImageResize\Listener;

use OCA\ImageResize\AppInfo\Application;
use OCA\ImageResize\BackgroundJob\ResizeImageJob;
use OCA\ImageResize\Service\ResizePolicy;
use OCP\BackgroundJob\IJobList;
use OCP\EventDispatcher\Event;
use OCP\EventDispatcher\IEventListener;
use OCP\Files\Events\Node\AbstractNodeEvent;
use OCP\Files\File;
use OCP\IConfig;
use Psr\Log\LoggerInterface;

/** @template-implements IEventListener<AbstractNodeEvent> */
final class ImageWriteListener implements IEventListener {
    public function __construct(
        private IJobList $jobList,
        private IConfig $config,
        private ResizePolicy $policy,
        private LoggerInterface $logger,
    ) {
    }

    public function handle(Event $event): void {
        if (!$event instanceof AbstractNodeEvent) {
            return;
        }

        if ($this->config->getAppValue(Application::APP_ID, 'enabled', '1') !== '1') {
            return;
        }

        $node = $event->getNode();
        if (!$node instanceof File || !$this->policy->isCandidate($node)) {
            return;
        }

        try {
            $owner = $node->getOwner();
            if ($owner === null) {
                return;
            }

            $argument = [
                'ownerUid' => $owner->getUID(),
                'fileId' => $node->getId(),
                'mtime' => $node->getMTime(),
            ];

            if (!$this->jobList->has(ResizeImageJob::class, $argument)) {
                $this->jobList->add(ResizeImageJob::class, $argument);
            }
        } catch (\Throwable $e) {
            $this->logger->warning('Could not queue image resize job: {message}', [
                'app' => Application::APP_ID,
                'message' => $e->getMessage(),
                'exception' => $e,
            ]);
        }
    }
}
