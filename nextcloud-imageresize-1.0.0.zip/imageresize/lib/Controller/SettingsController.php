<?php

declare(strict_types=1);

namespace OCA\ImageResize\Controller;

use OCA\ImageResize\AppInfo\Application;
use OCP\AppFramework\Controller;
use OCP\AppFramework\Http\Attribute\AdminRequired;
use OCP\AppFramework\Http\Attribute\NoAdminRequired;
use OCP\AppFramework\Http\JSONResponse;
use OCP\IConfig;
use OCP\IRequest;

final class SettingsController extends Controller {
    public function __construct(IRequest $request, private IConfig $config) {
        parent::__construct(Application::APP_ID, $request);
    }

    #[AdminRequired]
    public function save(
        bool $enabled,
        int $maxWidth,
        int $maxHeight,
        int $quality,
        int $maxInputMb,
        bool $stripMetadata,
        bool $skipAnimated,
        string $excludedFolders,
    ): JSONResponse {
        $values = [
            'enabled' => $enabled ? '1' : '0',
            'max_width' => (string)max(320, min(20000, $maxWidth)),
            'max_height' => (string)max(320, min(20000, $maxHeight)),
            'quality' => (string)max(30, min(100, $quality)),
            'max_input_mb' => (string)max(1, min(2048, $maxInputMb)),
            'strip_metadata' => $stripMetadata ? '1' : '0',
            'skip_animated' => $skipAnimated ? '1' : '0',
            'excluded_folders' => trim($excludedFolders),
        ];

        foreach ($values as $key => $value) {
            $this->config->setAppValue(Application::APP_ID, $key, $value);
        }

        return new JSONResponse(['status' => 'ok']);
    }
}
