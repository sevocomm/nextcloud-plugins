# Nextcloud Image Resize

A Nextcloud app that automatically resizes newly uploaded photos using the PHP Imagick extension.

## Features

- Runs asynchronously through the Nextcloud background-job queue.
- Preserves aspect ratio and never enlarges images.
- Supports JPEG, PNG, WebP, HEIC/HEIF and TIFF when supported by ImageMagick.
- Configurable maximum width/height, quality and maximum source file size.
- Optional removal of EXIF/metadata.
- Skips animated or multi-frame images by default.
- Excludes configured folders.
- Does not overwrite an image when the resized result would be larger.

## Requirements

- Nextcloud 30–35
- PHP 8.1+
- PHP Imagick extension
- Nextcloud background jobs configured as **Cron** (recommended)

Ubuntu/Debian example:

```bash
sudo apt update
sudo apt install php-imagick imagemagick
sudo systemctl restart apache2
# or restart the relevant PHP-FPM service
```

Verify:

```bash
php -m | grep -i imagick
```

## Installation

1. Extract the directory as `imageresize` under the Nextcloud `apps/` or `custom_apps/` directory.
2. Ensure the web-server user owns or can read the files.
3. Enable the app:

```bash
sudo -u www-data php occ app:enable imageresize
```

4. Open **Administration settings → Image Resize**.
5. Configure Nextcloud background jobs to use Cron.

## Behaviour and safety

The app changes the original uploaded file. Existing versions may be retained by Nextcloud's Versions app, depending on server configuration. For irreplaceable originals, configure an excluded folder such as `Photos/Originals`.

A resize is queued on file creation or write. Stale jobs are ignored when a newer upload/write has changed the file modification time. The listener validates MIME type and size before queueing, and the job validates again before processing.

## License

AGPL-3.0-or-later
