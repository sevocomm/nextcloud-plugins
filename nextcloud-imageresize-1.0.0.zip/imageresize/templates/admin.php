<?php
/** @var array $_ */
script('imageresize', 'admin');
style('imageresize', 'admin');
?>
<div id="imageresize-settings" class="section"
     data-save-url="<?php p(\OC::$server->getURLGenerator()->linkToRoute('imageresize.settings.save')); ?>">
    <h2><?php p($l->t('Image Resize')); ?></h2>
    <p><?php p($l->t('Automatically resize newly uploaded photos in the background using ImageMagick.')); ?></p>

    <?php if (!$_['imagickAvailable']): ?>
        <div class="warning"><?php p($l->t('PHP Imagick is not available. Install and enable php-imagick before activating processing.')); ?></div>
    <?php endif; ?>

    <p><label><input type="checkbox" id="ir-enabled" <?php if ($_['enabled'] === '1') print_unescaped('checked'); ?>> <?php p($l->t('Enable automatic resizing')); ?></label></p>
    <div class="ir-grid">
        <label><?php p($l->t('Maximum width (px)')); ?><input type="number" id="ir-max-width" min="320" max="20000" value="<?php p($_['maxWidth']); ?>"></label>
        <label><?php p($l->t('Maximum height (px)')); ?><input type="number" id="ir-max-height" min="320" max="20000" value="<?php p($_['maxHeight']); ?>"></label>
        <label><?php p($l->t('JPEG/WebP quality')); ?><input type="number" id="ir-quality" min="30" max="100" value="<?php p($_['quality']); ?>"></label>
        <label><?php p($l->t('Maximum source size (MB)')); ?><input type="number" id="ir-max-input" min="1" max="2048" value="<?php p($_['maxInputMb']); ?>"></label>
    </div>
    <p><label><input type="checkbox" id="ir-strip" <?php if ($_['stripMetadata'] === '1') print_unescaped('checked'); ?>> <?php p($l->t('Remove EXIF and other metadata')); ?></label></p>
    <p><label><input type="checkbox" id="ir-skip-animated" <?php if ($_['skipAnimated'] === '1') print_unescaped('checked'); ?>> <?php p($l->t('Skip animated and multi-frame images')); ?></label></p>
    <p><label for="ir-excluded"><?php p($l->t('Excluded folders')); ?></label><br>
       <textarea id="ir-excluded" rows="5" placeholder="Photos/Originals&#10;Archive"><?php p($_['excludedFolders']); ?></textarea><br>
       <em><?php p($l->t('One folder path per line. Matching is performed within each user’s files.')); ?></em>
    </p>
    <button id="ir-save" class="primary"><?php p($l->t('Save')); ?></button>
    <span id="ir-status" role="status"></span>
</div>
